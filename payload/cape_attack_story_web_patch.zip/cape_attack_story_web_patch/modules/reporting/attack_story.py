
import html
import json
import os
import re
from datetime import datetime
from pathlib import Path

try:
    from lib.cuckoo.common.abstracts import Report
    from lib.cuckoo.common.exceptions import CuckooReportError
except Exception:  # preview/test mode outside CAPE
    class Report:
        pass
    class CuckooReportError(Exception):
        pass

SUSPICIOUS_PATH_RE = re.compile(
    r"(?i)(\\temp\\|\\tasks\\|\\windows\\|readme|\\users\\|\\programdata\\|\\startup\\|\\system32\\|\\syswow64\\|\.dll$|\.exe$|\.dat$|\.tmp$|\.job$|\.lnk$|\.bat$|\.cmd$)"
)
NOISE_PROC_RE = re.compile(r"(?i)^(conhost\.exe|runtimebroker\.exe|sihost\.exe|ctfmon\.exe)$")
IMPORTANT_SIG_RE = re.compile(
    r"(?i)(ransom|wiper|scheduled|schtasks|inject|injection|defender|log|raw_disk|disk|mbr|recovery|uac|powershell|cmd|vss|shadow|service|process|persistence)"
)


def _short(text, limit=120):
    if text is None:
        return ""
    text = str(text).strip()
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _safe_name(path):
    if not path:
        return "(unknown)"
    try:
        return os.path.basename(path.replace('/', '\\')) or path
    except Exception:
        return str(path)


def _extract_commandline(proc):
    env = proc.get("environ") or {}
    return env.get("CommandLine") or proc.get("command_line") or ""


def _pick_root_pids(results, pid_map):
    roots = []
    for pid_str, fams in (results.get("detections2pid") or {}).items():
        try:
            pid = int(pid_str)
        except Exception:
            continue
        if pid in pid_map:
            roots.append(pid)
    if roots:
        return roots

    target_name = (results.get("target", {}).get("file", {}) or {}).get("name", "")
    target_sha = (results.get("target", {}).get("file", {}) or {}).get("sha256", "")
    for pid, proc in pid_map.items():
        cmd = _extract_commandline(proc)
        mod = proc.get("module_path", "")
        if target_name and target_name in cmd:
            roots.append(pid)
        elif target_name and target_name in mod:
            roots.append(pid)
        elif target_sha and target_sha[:16] in cmd:
            roots.append(pid)
    if roots:
        return roots

    processes = results.get("behavior", {}).get("processes") or []
    return [processes[0].get("process_id")] if processes else []


def _descendant_pids(root_pids, pid_map, max_depth=4):
    children = {}
    for pid, proc in pid_map.items():
        parent = proc.get("parent_id")
        children.setdefault(parent, []).append(pid)

    keep = set()
    frontier = [(pid, 0) for pid in root_pids if pid in pid_map]
    while frontier:
        pid, depth = frontier.pop(0)
        if pid in keep or depth > max_depth:
            continue
        keep.add(pid)
        for child in children.get(pid, []):
            frontier.append((child, depth + 1))
    return keep


def _interesting_files(file_activities):
    out = []
    for op_key, edge_type in (("write_files", "wrote"), ("delete_files", "deleted"), ("read_files", "read")):
        for path in file_activities.get(op_key) or []:
            if op_key == "read_files" and not SUSPICIOUS_PATH_RE.search(path or ""):
                continue
            out.append((edge_type, path))
    seen = set()
    uniq = []
    for item in out:
        if item in seen:
            continue
        seen.add(item)
        uniq.append(item)
    return uniq[:25]


def build_story(results):
    processes = results.get("behavior", {}).get("processes") or []
    pid_map = {int(p["process_id"]): p for p in processes if p.get("process_id") is not None}
    root_pids = _pick_root_pids(results, pid_map)
    kept_pids = _descendant_pids(root_pids, pid_map, max_depth=5)

    nodes = []
    edges = []
    node_ids = set()

    target = (results.get("target", {}).get("file") or {})
    sample_id = f"sample:{target.get('sha256') or target.get('name') or 'sample'}"
    sample_label = target.get("name") or target.get("sha256") or "sample"
    nodes.append({
        "id": sample_id,
        "kind": "sample",
        "label": _short(sample_label, 72),
        "meta": {
            "type": target.get("type", ""),
            "sha256": target.get("sha256", ""),
            "family": ((results.get("detections") or [{}])[0].get("family") if results.get("detections") else ""),
        },
    })
    node_ids.add(sample_id)

    for pid in kept_pids:
        proc = pid_map[pid]
        pname = proc.get("process_name") or f"pid {pid}"
        if NOISE_PROC_RE.search(pname):
            continue
        cmd = _extract_commandline(proc)
        pnode = {
            "id": f"proc:{pid}",
            "kind": "process",
            "label": pname,
            "meta": {
                "pid": pid,
                "parent_id": proc.get("parent_id"),
                "path": proc.get("module_path", ""),
                "cmd": cmd,
                "first_seen": proc.get("first_seen", ""),
            },
        }
        nodes.append(pnode)
        node_ids.add(pnode["id"])

    for pid in kept_pids:
        proc = pid_map[pid]
        parent = proc.get("parent_id")
        if parent in kept_pids and f"proc:{parent}" in node_ids:
            edges.append({"source": f"proc:{parent}", "target": f"proc:{pid}", "kind": "spawned"})
        else:
            edges.append({"source": sample_id, "target": f"proc:{pid}", "kind": "executed"})

    for pid in kept_pids:
        proc = pid_map[pid]
        for edge_kind, path in _interesting_files(proc.get("file_activities") or {}):
            fid = f"file:{path}"
            if fid not in node_ids:
                nodes.append({
                    "id": fid,
                    "kind": "file",
                    "label": _safe_name(path),
                    "meta": {"path": path},
                })
                node_ids.add(fid)
            edges.append({"source": f"proc:{pid}", "target": fid, "kind": edge_kind})

    ttps = sorted({ttp for item in (results.get("ttps") or []) for ttp in item.get("ttps", [])})
    if ttps:
        ttp_id = "bucket:ttps"
        nodes.append({"id": ttp_id, "kind": "bucket", "label": "MITRE / TTPs", "meta": {}})
        node_ids.add(ttp_id)
        edges.append({"source": sample_id, "target": ttp_id, "kind": "maps"})
        for ttp in ttps[:15]:
            nid = f"ttp:{ttp}"
            nodes.append({"id": nid, "kind": "ttp", "label": ttp, "meta": {}})
            node_ids.add(nid)
            edges.append({"source": ttp_id, "target": nid, "kind": "includes"})

    important_sigs = []
    for sig in results.get("signatures") or []:
        name = sig.get("name", "")
        if IMPORTANT_SIG_RE.search(name):
            important_sigs.append({
                "name": name,
                "severity": sig.get("severity"),
                "description": sig.get("description", ""),
            })
    if important_sigs:
        sid = "bucket:sigs"
        nodes.append({"id": sid, "kind": "bucket", "label": "Important Signatures", "meta": {}})
        node_ids.add(sid)
        edges.append({"source": sample_id, "target": sid, "kind": "flagged"})
        for sig in important_sigs[:15]:
            nid = f"sig:{sig['name']}"
            nodes.append({"id": nid, "kind": "signature", "label": sig["name"], "meta": sig})
            node_ids.add(nid)
            edges.append({"source": sid, "target": nid, "kind": "includes"})

    highlights = []
    for pid in kept_pids:
        proc = pid_map[pid]
        cmd = _extract_commandline(proc)
        if cmd:
            highlights.append(f"{proc.get('process_name')} :: {cmd}")
    highlights = highlights[:12]

    return {
        "meta": {
            "task_id": results.get("info", {}).get("id"),
            "family": ((results.get("detections") or [{}])[0].get("family") if results.get("detections") else ""),
            "malscore": results.get("malscore"),
            "malstatus": results.get("malstatus"),
            "generated_at": datetime.utcnow().isoformat() + "Z",
        },
        "roots": [sample_id],
        "highlights": highlights,
        "nodes": nodes,
        "edges": edges,
    }


def build_html(story):
    meta = story.get("meta", {})
    nodes = story.get("nodes", [])
    edges = story.get("edges", [])

    children = {}
    nmap = {n["id"]: n for n in nodes}
    for e in edges:
        children.setdefault(e["source"], []).append((e["kind"], e["target"]))

    def render(node_id, seen=None):
        seen = seen or set()
        if node_id in seen or node_id not in nmap:
            return ""
        seen = set(seen)
        seen.add(node_id)
        n = nmap[node_id]
        kind = html.escape(n.get("kind", ""))
        label = html.escape(n.get("label", ""))
        meta_items = []
        for k, v in (n.get("meta") or {}).items():
            if not v:
                continue
            meta_items.append(f"<div><b>{html.escape(str(k))}</b>: {html.escape(_short(v, 180))}</div>")
        meta_html = "".join(meta_items)
        kids = children.get(node_id, [])
        if kids:
            kids_html = "<ul>" + "".join(
                f"<li><span class='edge'>{html.escape(kind_)}</span>{render(child_id, seen)}</li>"
                for kind_, child_id in kids
            ) + "</ul>"
        else:
            kids_html = ""
        return (
            f"<div class='node kind-{kind}'>"
            f"<div class='title'>{label}</div>"
            f"<div class='badge'>{kind}</div>"
            f"<div class='meta'>{meta_html}</div>"
            f"</div>{kids_html}"
        )

    roots_html = "<ul class='mindmap'>" + "".join(f"<li>{render(root)}</li>" for root in story.get("roots", [])) + "</ul>"
    highlights_html = "".join(f"<li>{html.escape(h)}</li>" for h in story.get("highlights", []))
    data_json = html.escape(json.dumps(story, ensure_ascii=False, indent=2))

    return f"""<!doctype html>
<html lang='en'>
<head>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<title>Attack Story</title>
<style>
body {{ font-family: Inter, Segoe UI, Arial, sans-serif; margin: 0; background: #0f1115; color: #e9eef5; }}
header {{ padding: 18px 22px; border-bottom: 1px solid #262c36; background: #141922; position: sticky; top: 0; z-index: 2; }}
header h1 {{ margin: 0 0 8px; font-size: 22px; }}
header .meta {{ color: #b8c0cc; font-size: 14px; }}
.container {{ padding: 18px 22px 40px; }}
.panel {{ background: #161b23; border: 1px solid #2a3240; border-radius: 12px; padding: 16px; margin-bottom: 18px; }}
.panel h2 {{ margin: 0 0 12px; font-size: 18px; }}
.mindmap, .mindmap ul {{ list-style: none; margin: 0; padding-left: 28px; position: relative; }}
.mindmap ul::before {{ content: ''; position: absolute; left: 10px; top: 0; bottom: 12px; width: 2px; background: #344156; }}
.mindmap li {{ margin: 14px 0; position: relative; }}
.mindmap li::before {{ content: ''; position: absolute; left: -18px; top: 22px; width: 18px; height: 2px; background: #344156; }}
.node {{ display: inline-block; min-width: 320px; max-width: 900px; vertical-align: top; padding: 12px 14px; border-radius: 12px; border: 1px solid #334155; background: #0f1724; box-shadow: 0 2px 8px rgba(0,0,0,.18); }}
.node .title {{ font-weight: 700; margin-bottom: 6px; }}
.node .badge {{ display: inline-block; font-size: 12px; padding: 3px 8px; border-radius: 999px; margin-bottom: 8px; background: #243041; color: #cbd5e1; }}
.node .meta {{ color: #c4ceda; font-size: 13px; line-height: 1.45; }}
.kind-sample {{ border-color: #2f81f7; background: #0f1e38; }}
.kind-process {{ border-color: #8b5cf6; }}
.kind-file {{ border-color: #10b981; }}
.kind-ttp {{ border-color: #f59e0b; }}
.kind-signature {{ border-color: #ef4444; }}
.kind-bucket {{ border-color: #64748b; background: #111827; }}
.edge {{ display: inline-block; min-width: 78px; color: #93c5fd; font-size: 12px; margin-right: 8px; text-transform: uppercase; letter-spacing: .04em; }}
pre {{ overflow: auto; background: #0b0f16; border: 1px solid #273142; border-radius: 10px; padding: 12px; color: #d1d5db; }}
small.note {{ color: #97a6ba; }}
</style>
</head>
<body>
<header>
  <h1>Attack Story</h1>
  <div class='meta'>Task #{html.escape(str(meta.get('task_id')))} · family={html.escape(str(meta.get('family')))} · malscore={html.escape(str(meta.get('malscore')))} · status={html.escape(str(meta.get('malstatus')))}</div>
</header>
<div class='container'>
  <div class='panel'>
    <h2>Highlights</h2>
    <ul>{highlights_html or '<li>No high-signal highlights extracted.</li>'}</ul>
    <small class='note'>This view is intentionally filtered to emphasize roots, child processes, suspicious file operations, and matched TTP/signature context.</small>
  </div>
  <div class='panel'>
    <h2>Mindmap</h2>
    {roots_html}
  </div>
  <div class='panel'>
    <h2>Raw JSON</h2>
    <pre>{data_json}</pre>
  </div>
</div>
</body>
</html>"""


class AttackStory(Report):
    """Generate a high-signal attack story JSON + HTML from CAPE results."""
    order = 999

    def run(self, results):
        try:
            story = build_story(results)
            reports_path = getattr(self, "reports_path", os.getcwd())
            json_path = os.path.join(reports_path, "attack_story.json")
            html_path = os.path.join(reports_path, "attack_story.html")
            Path(json_path).write_text(json.dumps(story, ensure_ascii=False, indent=2), encoding="utf-8")
            Path(html_path).write_text(build_html(story), encoding="utf-8")
            return True
        except Exception as e:
            raise CuckooReportError(f"Failed to generate attack story: {e}")
