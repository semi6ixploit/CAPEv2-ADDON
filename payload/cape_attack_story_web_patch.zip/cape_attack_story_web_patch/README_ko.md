# CAPE Attack Story Web 통합 패치

이 패치는 두 가지를 한 번에 설치합니다.

1. **Reporting 모듈**
   - 새 분석 작업마다 `reports/attack_story.json`, `reports/attack_story.html` 자동 생성
2. **Web UI 통합**
   - CAPE 분석 상세 페이지에 **Attack Story 섹션** 추가
   - `iframe`으로 `/analysis/<taskid>/attack_story/` 를 임베드

## 설치

```bash
cd /mnt/data/cape_attack_story_web_patch
sudo ./install_attack_story_web.sh /opt/CAPEv2
```

## 설치 후
- `custom/conf/reporting.conf`에 `[attack_story] enabled = on` 보장
- `web/analysis/urls.py`에 Attack Story 라우트 추가
- `web/templates/analysis/report.html`에 Attack Story 섹션 추가
- `modules/reporting/attack_story.py` 설치
- `utils/attack_story_rebuild.py` 설치

## 기존 리포트 재생성

```bash
python3 /opt/CAPEv2/utils/attack_story_rebuild.py /opt/CAPEv2/storage/analyses/17/reports/report.json
```

## 동작 확인
1. 새 샘플 분석 완료
2. `/opt/CAPEv2/storage/analyses/<taskid>/reports/attack_story.html` 생성 확인
3. CAPE 웹 상세 페이지에서 **Attack Story** 섹션 확인
4. 직접 열려면 `/analysis/<taskid>/attack_story/`

## 주의
- `report.html`, `urls.py`를 자동 패치하므로 설치 전에 백업이 자동 생성됩니다.
- 백업 위치: `/opt/CAPEv2/attack_story_web_backups/<timestamp>/`
- 템플릿 구조가 크게 다른 포크에서는 자동 패치가 실패할 수 있습니다.
