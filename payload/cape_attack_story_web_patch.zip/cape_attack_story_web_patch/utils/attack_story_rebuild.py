#!/usr/bin/env python3
import argparse
import importlib.util
import json
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
MODULE_PATH = SCRIPT_DIR.parent / "modules" / "reporting" / "attack_story.py"
spec = importlib.util.spec_from_file_location("attack_story", MODULE_PATH)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

def main():
    ap = argparse.ArgumentParser(description="Rebuild attack_story.{json,html} from a report.json")
    ap.add_argument("report_json", help="Path to report.json")
    ap.add_argument("--outdir", help="Output directory (default: sibling reports dir)")
    args = ap.parse_args()
    report_json = Path(args.report_json).resolve()
    outdir = Path(args.outdir).resolve() if args.outdir else report_json.parent
    outdir.mkdir(parents=True, exist_ok=True)
    data = json.loads(report_json.read_text(encoding="utf-8"))
    story = mod.build_story(data)
    (outdir / "attack_story.json").write_text(json.dumps(story, ensure_ascii=False, indent=2), encoding="utf-8")
    (outdir / "attack_story.html").write_text(mod.build_html(story), encoding="utf-8")
    print(f"wrote: {outdir / 'attack_story.json'}")
    print(f"wrote: {outdir / 'attack_story.html'}")

if __name__ == "__main__":
    main()
