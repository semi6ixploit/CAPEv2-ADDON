from pathlib import Path
from django.conf import settings
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required


def _wrap_html(body: str, status: int = 200) -> HttpResponse:
    return HttpResponse(body, status=status, content_type="text/html; charset=utf-8")


@login_required
def attack_story(request, task_id: int):
    base = Path(settings.CUCKOO_PATH) / "storage" / "analyses" / str(task_id) / "reports"
    html_path = base / "attack_story.html"
    json_path = base / "attack_story.json"
    if html_path.exists():
        return _wrap_html(html_path.read_text(encoding="utf-8", errors="replace"))

    if json_path.exists():
        body = f"""<!doctype html>
<html><head><meta charset='utf-8'><title>Attack Story Pending</title>
<style>
body {{ font-family: Segoe UI, Arial, sans-serif; background:#0f1115; color:#e9eef5; margin:0; }}
.wrap {{ max-width: 980px; margin: 30px auto; padding: 0 16px; }}
.card {{ background:#161b23; border:1px solid #2a3240; border-radius:12px; padding:16px; }}
a {{ color:#93c5fd; }}
pre {{ background:#0b0f16; border:1px solid #273142; border-radius:10px; padding:12px; white-space:pre-wrap; word-break:break-word; }}
</style></head><body><div class='wrap'><div class='card'>
<h2>Attack Story HTML is missing, but JSON exists.</h2>
<p>Rebuild the HTML with:</p>
<pre>python3 {settings.CUCKOO_PATH}/utils/attack_story_rebuild.py {settings.CUCKOO_PATH}/storage/analyses/{task_id}/reports/report.json</pre>
<p>JSON path: <code>{json_path}</code></p>
</div></div></body></html>"""
        return _wrap_html(body)

    body = f"""<!doctype html>
<html><head><meta charset='utf-8'><title>Attack Story Not Available</title>
<style>
body {{ font-family: Segoe UI, Arial, sans-serif; background:#0f1115; color:#e9eef5; margin:0; }}
.wrap {{ max-width: 980px; margin: 30px auto; padding: 0 16px; }}
.card {{ background:#161b23; border:1px solid #2a3240; border-radius:12px; padding:16px; }}
code, pre {{ background:#0b0f16; border:1px solid #273142; border-radius:10px; padding:12px; display:block; white-space:pre-wrap; word-break:break-word; }}
</style></head><body><div class='wrap'><div class='card'>
<h2>Attack Story is not available for task #{task_id}</h2>
<p>This usually means the reporting module is not installed, the task predates installation, or the report has not been rebuilt yet.</p>
<p>Rebuild with:</p>
<pre>python3 {settings.CUCKOO_PATH}/utils/attack_story_rebuild.py {settings.CUCKOO_PATH}/storage/analyses/{task_id}/reports/report.json</pre>
</div></div></body></html>"""
    return _wrap_html(body, status=404)
