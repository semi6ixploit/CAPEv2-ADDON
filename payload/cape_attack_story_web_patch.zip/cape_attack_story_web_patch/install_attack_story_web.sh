#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-/opt/CAPEv2}"
PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP_DIR="$ROOT/attack_story_web_backups/$STAMP"
mkdir -p "$BACKUP_DIR" "$ROOT/modules/reporting" "$ROOT/custom/conf" "$ROOT/utils" "$ROOT/web/analysis" "$ROOT/web/templates/analysis/attack_story"

backup_if_exists() {
  local f="$1"
  if [[ -f "$f" ]]; then
    mkdir -p "$BACKUP_DIR/$(dirname "${f#$ROOT/}")"
    cp "$f" "$BACKUP_DIR/${f#$ROOT/}.bak"
  fi
}

backup_if_exists "$ROOT/modules/reporting/attack_story.py"
backup_if_exists "$ROOT/utils/attack_story_rebuild.py"
backup_if_exists "$ROOT/custom/conf/reporting.conf"
backup_if_exists "$ROOT/web/analysis/urls.py"
backup_if_exists "$ROOT/web/templates/analysis/report.html"
backup_if_exists "$ROOT/web/analysis/attack_story_views.py"

install -m 0644 "$PATCH_DIR/modules/reporting/attack_story.py" "$ROOT/modules/reporting/attack_story.py"
install -m 0755 "$PATCH_DIR/utils/attack_story_rebuild.py" "$ROOT/utils/attack_story_rebuild.py"
install -m 0644 "$PATCH_DIR/web/analysis/attack_story_views.py" "$ROOT/web/analysis/attack_story_views.py"
install -m 0644 "$PATCH_DIR/web/templates/analysis/attack_story/index.html" "$ROOT/web/templates/analysis/attack_story/index.html"

CONF_FILE="$ROOT/custom/conf/reporting.conf"
if [[ -f "$CONF_FILE" ]]; then
  if ! grep -q '^\[attack_story\]' "$CONF_FILE"; then
    printf '\n[attack_story]\nenabled = on\n' >> "$CONF_FILE"
  fi
else
  install -m 0644 "$PATCH_DIR/custom/conf/reporting.conf" "$CONF_FILE"
fi

python3 - "$ROOT" <<'PY'
import sys
from pathlib import Path
root = Path(sys.argv[1])

# Patch web/analysis/urls.py
urls = root / "web" / "analysis" / "urls.py"
text = urls.read_text(encoding="utf-8")
if "attack_story_views" not in text:
    text = text.replace("from analysis import views", "from analysis import views\nfrom analysis import attack_story_views")
route = 're_path(r"^(?P<task_id>\\d+)/attack_story/$", attack_story_views.attack_story, name="attack_story"), '
if "name=\"attack_story\"" not in text:
    marker = 're_path(r"^(?P<task_id>\\d+)/comments/$", views.comments, name="comments"), '
    if marker in text:
        text = text.replace(marker, marker + route)
    else:
        # append before closing bracket if marker format changed
        idx = text.rfind("]")
        if idx == -1:
            raise SystemExit("Could not patch urls.py: urlpatterns closing bracket not found")
        text = text[:idx] + route + text[idx:]
urls.write_text(text, encoding="utf-8")

# Patch web/templates/analysis/report.html
report = root / "web" / "templates" / "analysis" / "report.html"
rt = report.read_text(encoding="utf-8")
nav_snippet = '  * <a href="#attack_story_section">Attack Story</a> '
if '#attack_story_section' not in rt:
    rt = rt.replace('  * 【0† Quick Overview 】', '  * 【0† Quick Overview 】\n' + nav_snippet, 1)
include_snippet = ' {% include "analysis/attack_story/index.html" %}\n'
if 'analysis/attack_story/index.html' not in rt:
    anchor = '{% include "analysis/overview/index.html" %}'
    if anchor in rt:
        rt = rt.replace(anchor, anchor + '\n\n' + include_snippet, 1)
    else:
        raise SystemExit("Could not patch report.html: overview include not found")
report.write_text(rt, encoding="utf-8")
PY

echo "[+] Installed attack_story reporting + web integration"
echo "[+] Backups: $BACKUP_DIR"
if command -v systemctl >/dev/null 2>&1; then
  echo "[+] Restarting CAPE services (best effort)"
  sudo systemctl restart cape || true
  sudo systemctl restart cape-processor || true
  sudo systemctl restart cape-web || true
fi
cat <<EOF
[+] Done
    New analyses should auto-generate:
      $ROOT/storage/analyses/<taskid>/reports/attack_story.json
      $ROOT/storage/analyses/<taskid>/reports/attack_story.html
    And the CAPE report page should show an embedded Attack Story section.
EOF
