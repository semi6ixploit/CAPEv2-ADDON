# CAPE custom signatures pack

이 팩은 CAPE의 `modules/signatures/windows/` 아래에 넣어 쓰는 커스텀 시그니처 5종과
공용 헬퍼 1개로 구성되어 있습니다.

포함 파일
- `_custom_helpers.py`
- `custom_driver_rootkit_combo.py`
- `custom_credential_dumping_combo.py`
- `custom_ransomware_impact_combo.py`
- `custom_memory_injection_combo.py`
- `custom_anti_analysis_combo.py`

## 설치

```bash
cd /opt/CAPEv2

sudo cp /경로/_custom_helpers.py modules/signatures/windows/
sudo cp /경로/custom_driver_rootkit_combo.py modules/signatures/windows/
sudo cp /경로/custom_credential_dumping_combo.py modules/signatures/windows/
sudo cp /경로/custom_ransomware_impact_combo.py modules/signatures/windows/
sudo cp /경로/custom_memory_injection_combo.py modules/signatures/windows/
sudo cp /경로/custom_anti_analysis_combo.py modules/signatures/windows/

sudo systemctl restart cape cape-processor
```

## 기존 분석 재처리

```bash
cd /opt/CAPEv2
sudo -u cape -H /etc/poetry/bin/poetry run python utils/process.py -r <TASK_ID> -s
```

## 설계 메모

- 정확한 한 개 JSON 경로에만 의존하지 않도록 `results` 전체를 재귀적으로 훑되,
  기존 `signatures` 섹션은 제외합니다.
- 그래서 CAPE 버전이나 리포트 레이아웃 차이가 조금 있어도 비교적 덜 깨지게 만들었습니다.
- 대신 evented API-call 시그니처보다 보수적이며, 문자열/행위 흔적의 조합으로 탐지합니다.

## 추천 다음 단계

1. 네 샘플 몇 개에 먼저 태워서 false positive를 본다.
2. evidence 항목을 기준으로 키워드를 줄이거나 늘린다.
3. 너희 환경에서 많이 나오는 정상 툴/드라이버/관리 스크립트는 제외 규칙을 추가한다.
