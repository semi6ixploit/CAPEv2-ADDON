# -*- coding: utf-8 -*-
from lib.cuckoo.common.abstracts import Signature
from modules.signatures.windows._custom_helpers import keyword_hits, summarize_presence


class CustomRansomwareImpactCombo(Signature):
    name = "custom_ransomware_impact_combo"
    description = "대량 파일 변경과 복구 방해를 동반한 랜섬웨어/와이퍼성 징후"
    severity = 3
    confidence = 85
    weight = 5
    categories = ["generic"]
    authors = ["OpenAI"]
    minimum = "1.0"
    ttps = ["T1486", "T1490"]
    mbcs = ["D0013", "D0009"]

    def run(self):
        file_patterns = [
            "ransomware_file_modifications", "ransomware_files",
            "ransomware_extension", "encrypted", "encryption", "rename",
            "createfile", "writefile", "mass", "file modification",
            "ransom note", "decrypt", "readme", ".locked", ".encrypted",
        ]
        impact_patterns = [
            "vssadmin delete shadows", "wmic shadowcopy delete",
            "wbadmin delete", "bcdedit", "deletes_shadow_copies",
            "deletes_system_state_backup", "disables_backups",
            "ransomware_recyclebin", "wevtutil cl", "cipher /w",
        ]

        evidence_a, hits_a = keyword_hits(self.results, file_patterns, regex=True)
        evidence_b, hits_b = keyword_hits(self.results, impact_patterns, regex=True)

        if (hits_a >= 3 and hits_b >= 1) or hits_b >= 2:
            return summarize_presence(self, evidence_a + evidence_b, kind="evidence")
        return False
