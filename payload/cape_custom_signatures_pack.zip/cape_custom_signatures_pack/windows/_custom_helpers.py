# -*- coding: utf-8 -*-
"""
Schema-tolerant helpers for CAPE custom signatures.

These helpers intentionally search across the analysis result tree while
excluding the "signatures" section, so the custom signatures don't depend on
one exact report layout and don't self-trigger on existing signature text.
"""

from __future__ import annotations

import re
from typing import Dict, Iterable, Iterator, List, Sequence, Tuple


def _walk_strings(obj, parent_key: str = "") -> Iterator[str]:
    """Yield string content from nested dict/list structures.

    Excludes any branch under a key named "signatures".
    """
    if isinstance(obj, dict):
        for key, value in obj.items():
            if key == "signatures":
                continue
            if isinstance(key, str):
                yield key
            yield from _walk_strings(value, key)
    elif isinstance(obj, (list, tuple, set)):
        for item in obj:
            yield from _walk_strings(item, parent_key)
    elif isinstance(obj, bytes):
        try:
            yield obj.decode("utf-8", errors="ignore")
        except Exception:
            return
    elif isinstance(obj, str):
        yield obj


def normalized_strings(results: Dict) -> List[str]:
    """Return all strings from results, normalized once."""
    out = []
    for s in _walk_strings(results):
        s = re.sub(r"\s+", " ", s).strip()
        if s:
            out.append(s)
    return out


def _compile(patterns: Sequence[str], regex: bool = False):
    if regex:
        return [re.compile(p, re.I) for p in patterns]
    return patterns


def count_pattern_hits(strings: Sequence[str], patterns: Sequence[str], regex: bool = False) -> int:
    """Count distinct pattern hits across the provided strings."""
    count = 0
    if regex:
        compiled = _compile(patterns, regex=True)
        for pat in compiled:
            if any(pat.search(s) for s in strings):
                count += 1
    else:
        lowered = [s.lower() for s in strings]
        for pat in patterns:
            p = pat.lower()
            if any(p in s for s in lowered):
                count += 1
    return count


def any_pattern(strings: Sequence[str], patterns: Sequence[str], regex: bool = False) -> bool:
    return count_pattern_hits(strings, patterns, regex=regex) > 0


def keyword_hits(results: Dict, patterns: Sequence[str], regex: bool = False) -> Tuple[List[str], int]:
    """Return sample evidence strings and the number of matched patterns."""
    strings = normalized_strings(results)
    evidence: List[str] = []
    if regex:
        compiled = _compile(patterns, regex=True)
        seen = set()
        for pat in compiled:
            for s in strings:
                if pat.search(s):
                    if s not in seen:
                        evidence.append(s[:220])
                        seen.add(s)
                    break
    else:
        lowered = [(s, s.lower()) for s in strings]
        seen = set()
        for pat in patterns:
            p = pat.lower()
            for original, low in lowered:
                if p in low:
                    if original not in seen:
                        evidence.append(original[:220])
                        seen.add(original)
                    break
    return evidence[:10], count_pattern_hits(strings, patterns, regex=regex)


def summarize_presence(signature, evidence: Iterable[str], kind: str = "indicator") -> bool:
    """Add evidence rows and return True if there is any evidence."""
    evidence = list(evidence)
    for item in evidence[:10]:
        signature.data.append({kind: item})
    return bool(evidence)
