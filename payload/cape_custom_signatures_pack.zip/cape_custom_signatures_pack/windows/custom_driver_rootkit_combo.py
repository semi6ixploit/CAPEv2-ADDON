# -*- coding: utf-8 -*-
from lib.cuckoo.common.abstracts import Signature
from modules.signatures.windows._custom_helpers import keyword_hits, summarize_presence


class CustomDriverRootkitCombo(Signature):
    name = "custom_driver_rootkit_combo"
    description = "커널 드라이버 설치/로드 및 루트킷성 행위를 시사하는 조합 징후"
    severity = 3
    confidence = 85
    weight = 4
    categories = ["generic"]
    authors = ["OpenAI"]
    minimum = "1.0"
    ttps = ["T1547.006", "T1068", "T1543.003"]
    mbcs = ["B0003", "E1055"]

    def run(self):
        driver_patterns = [
            "ntloaddriver", "zwloaddriver", "service_kernel_driver",
            r"\\drivers\\.*\.sys", ".sys", "create service", "createservice",
            "startservice", "install kernel driver service", "driver load",
            "sc.exe create", "fltmc", "filter manager", "driver_filtermanager",
        ]
        risky_patterns = [
            "deviceiocontrol", "ioctl", "physicaldrive", "direct_hdd_access",
            "pendingfilerenameoperations", "hvcidisallowedimages",
            "disable_hypervisor_protected_code_integrity", "byovd",
            "vulnerable driver", "rootkit",
        ]

        evidence_a, hits_a = keyword_hits(self.results, driver_patterns, regex=True)
        evidence_b, hits_b = keyword_hits(self.results, risky_patterns, regex=True)

        if hits_a >= 2 and (hits_b >= 1 or any(".sys" in x.lower() for x in evidence_a)):
            return summarize_presence(self, evidence_a + evidence_b, kind="evidence")
        return False
