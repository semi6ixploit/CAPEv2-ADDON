# -*- coding: utf-8 -*-
from lib.cuckoo.common.abstracts import Signature
from modules.signatures.windows._custom_helpers import keyword_hits, summarize_presence


class CustomMemoryInjectionCombo(Signature):
    name = "custom_memory_injection_combo"
    description = "프로세스 인젝션/비백업 메모리 실행을 시사하는 고신뢰 조합 징후"
    severity = 3
    confidence = 90
    weight = 5
    categories = ["generic"]
    authors = ["OpenAI"]
    minimum = "1.0"
    ttps = ["T1055", "T1620"]
    mbcs = ["B0040", "E1055"]

    def run(self):
        injection_patterns = [
            "writeprocessmemory", "createremotethread", "rtlcreateuserthread",
            "queueuserapc", "setthreadcontext", "resumethread",
            "virtualallocex", "ntallocatevirtualmemory", "ntmapviewofsection",
            "process hollowing", "injection_", "runpe", "module stomping",
            "unbacked", "shellcode", "page_execute_readwrite", "rwx",
        ]
        evasion_patterns = [
            "edr unhook", "modify ntdll", "setunhandledexceptionfilter",
            "manual api", "syscall", "direct syscall", "unhook",
        ]

        evidence_a, hits_a = keyword_hits(self.results, injection_patterns, regex=True)
        evidence_b, hits_b = keyword_hits(self.results, evasion_patterns, regex=True)

        if hits_a >= 3 or (hits_a >= 2 and hits_b >= 1):
            return summarize_presence(self, evidence_a + evidence_b, kind="evidence")
        return False
