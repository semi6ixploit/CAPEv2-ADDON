# -*- coding: utf-8 -*-
from lib.cuckoo.common.abstracts import Signature
from modules.signatures.windows._custom_helpers import keyword_hits, summarize_presence


class CustomCredentialDumpingCombo(Signature):
    name = "custom_credential_dumping_combo"
    description = "자격 증명 덤프/탈취를 시사하는 고신뢰 조합 징후"
    severity = 3
    confidence = 90
    weight = 5
    categories = ["generic"]
    authors = ["OpenAI"]
    minimum = "1.0"
    ttps = ["T1003", "T1555", "T1552"]
    mbcs = ["C0036", "C0028"]

    def run(self):
        core_patterns = [
            "lsass", "minidumpwritedump", "comsvcs.dll", "procdump",
            "sekurlsa", "mimikatz", "lsass.dmp", "rundll32.exe comsvcs",
            "credentialdump", "dump_lsa",
        ]
        store_patterns = [
            r"\\sam$", r"\\security$", r"\\system$", "policy\\secrets",
            "wdigest", "vaultcmd", "credential store", "credwiz",
            "access_windows_passwords_vault", "registry_lsa_secrets_access",
            "file_credential_store_access", "registry_credential_store_access",
        ]

        evidence_a, hits_a = keyword_hits(self.results, core_patterns, regex=True)
        evidence_b, hits_b = keyword_hits(self.results, store_patterns, regex=True)

        strong_pair = hits_a >= 2 or ("lsass" in " ".join(evidence_a).lower() and any("dump" in e.lower() for e in evidence_a + evidence_b))
        if strong_pair or (hits_a >= 1 and hits_b >= 1):
            return summarize_presence(self, evidence_a + evidence_b, kind="evidence")
        return False
