# -*- coding: utf-8 -*-
from lib.cuckoo.common.abstracts import Signature
from modules.signatures.windows._custom_helpers import keyword_hits, summarize_presence


class CustomAntiAnalysisCombo(Signature):
    name = "custom_anti_analysis_combo"
    description = "안티디버깅/안티샌드박스/안티VM 조합 징후"
    severity = 3
    confidence = 80
    weight = 4
    categories = ["generic"]
    authors = ["OpenAI"]
    minimum = "1.0"
    ttps = ["T1497", "T1622"]
    mbcs = ["B0001", "E1029"]

    def run(self):
        anti_debug = [
            "isdebuggerpresent", "checkremotedebuggerpresent",
            "setunhandledexceptionfilter", "outputdebugstring",
            "debugactiveprocess", "gettickcount", "guard page",
            "addvectoredexceptionhandler", "ntsetinformationthread",
        ]
        anti_sandbox_vm = [
            "vmware", "virtualbox", "qemu", "xen", "hyper-v", "bochs",
            "wine", "sandboxie", "cuckoo", "joe", "fortinet", "sunbelt",
            "mouse movement", "foreground window", "volume serial",
            "physical hardware id", "locale", "keyboard layout", "userdomain",
            "sleep", "delay analysis",
        ]

        evidence_a, hits_a = keyword_hits(self.results, anti_debug, regex=True)
        evidence_b, hits_b = keyword_hits(self.results, anti_sandbox_vm, regex=True)

        if hits_a >= 2 or (hits_a >= 1 and hits_b >= 2) or hits_b >= 3:
            return summarize_presence(self, evidence_a + evidence_b, kind="evidence")
        return False
